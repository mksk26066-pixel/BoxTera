const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const axios = require('axios');
const rateLimit = require('express-rate-limit');
const path = require('path');
const { CookieJar } = require('tough-cookie');
const { wrapper } = require('axios-cookiejar-support');

const app = express();
const PORT = process.env.PORT || 3000;

// --- CONFIGURATION ---
const TERABOX_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36";

// --- MIDDLEWARE ---
app.use(helmet({
  contentSecurityPolicy: false, // Disabled to allow video buffering
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Rate Limiter (Prevents abuse)
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: { success: false, message: "Too many requests, please try again later." }
});
app.use('/api/', apiLimiter);

// --- HTTP CLIENT SETUP ---
const jar = new CookieJar();
const client = wrapper(axios.create({ jar }));

// --- UTILS ---
const getShortKey = (url) => {
  try {
    const urlObj = new URL(url);
    const pathSegments = urlObj.pathname.split('/');
    // Handles /s/1key or /s/key
    return pathSegments[pathSegments.length - 1].replace(/^1/, ''); 
  } catch (e) {
    return null;
  }
};

// --- API ENDPOINTS ---

/**
 * Endpoint: /api/convert
 * Validates TeraBox URL and fetches video metadata
 */
app.post('/api/convert', async (req, res) => {
  const { url } = req.body;

  if (!url || !url.includes('terabox')) {
    return res.status(400).json({ success: false, message: 'Invalid TeraBox URL' });
  }

  try {
    const shortKey = getShortKey(url);
    if (!shortKey) throw new Error("Could not parse short key");

    // 1. Initial Handshake (Get Cookies)
    await client.get(url, {
      headers: {
        'User-Agent': TERABOX_UA,
        'Connection': 'keep-alive'
      }
    });

    // 2. Fetch File Info (Simulated Logic for TeraBox API)
    // Note: In a real production scenario, this endpoint often rotates.
    // We query the share/list endpoint which is standard.
    const apiParams = new URLSearchParams({
        app_id: '250528',
        shorturl: shortKey,
        root: '1'
    });

    const apiUrl = `https://www.terabox.com/share/list?${apiParams.toString()}`;

    const apiResponse = await client.get(apiUrl, {
      headers: {
        'User-Agent': TERABOX_UA,
        'Referer': url,
        'X-Requested-With': 'XMLHttpRequest'
      }
    });

    const data = apiResponse.data;

    // Check for TeraBox error codes
    if (data.errno !== 0 || !data.list || data.list.length === 0) {
      throw new Error('Video not found. Link might be private or expired.');
    }

    const file = data.list[0];

    // Generate Proxy URLs
    // We assume the frontend is on the same domain.
    const baseUrl = `${req.protocol}://${req.get('host')}`;
    const proxyStreamUrl = `${baseUrl}/api/proxy/stream?dlink=${encodeURIComponent(file.dlink)}`;
    const proxyDownloadUrl = `${proxyStreamUrl}&download=1`;

    res.json({
      success: true,
      data: {
        filename: file.server_filename,
        size: file.size,
        thumb: file.thumbs ? file.thumbs.url3 : null,
        stream_url: proxyStreamUrl,
        download_url: proxyDownloadUrl,
        resolutions: file.resolution || "HD"
      }
    });

  } catch (error) {
    console.error('Extraction Error:', error.message);
    res.status(500).json({ 
        success: false, 
        message: 'Failed to process video. TeraBox API may be busy.' 
    });
  }
});

/**
 * Endpoint: /api/proxy/stream
 * Proxies the video stream to bypass Referer/CORS restrictions
 */
app.get('/api/proxy/stream', async (req, res) => {
  const { dlink, download } = req.query;

  if (!dlink) return res.status(400).send('Missing download link');

  try {
    // Request video stream from TeraBox with valid headers
    const response = await axios({
      method: 'GET',
      url: dlink,
      headers: {
        'User-Agent': TERABOX_UA,
        'Referer': 'https://www.terabox.com/',
        'Accept': '*/*'
      },
      responseType: 'stream'
    });

    // Mirror content headers
    if (response.headers['content-length']) {
      res.setHeader('Content-Length', response.headers['content-length']);
    }
    res.setHeader('Content-Type', response.headers['content-type'] || 'video/mp4');

    // Handle Download vs Stream
    if (download === '1') {
      res.setHeader('Content-Disposition', `attachment; filename="video_${Date.now()}.mp4"`);
    }

    // Pipe the stream
    response.data.pipe(res);

  } catch (error) {
    console.error('Stream Proxy Error:', error.message);
    // If pipe breaks, just end response
    res.end(); 
  }
});

// Serve Frontend for unknown routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});