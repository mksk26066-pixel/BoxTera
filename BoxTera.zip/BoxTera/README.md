# TeraPlayer - TeraBox Video Converter & Player

A production-ready web application that converts TeraBox sharing links into direct streamable video URLs. Features a modern UI, HTML5 player, and direct download functionality without requiring the official app.

## 🚀 Features

- **Link Extraction:** Parses standard TeraBox/1024Tera URLs.
- **Proxy Streaming:** Bypasses Referer/CORS restrictions for browser playback.
- **HTML5 Player:** Integrated Plyr.io video player.
- **Direct Download:** Generates direct download links.
- **Security:** Rate limiting, Helmet security headers, and sanitized inputs.
- **Responsive:** Mobile-first design using modern CSS3.

## 🛠 Installation

### Prerequisites
- Node.js (v16 or higher)
- NPM or Yarn

### Local Setup

1. **Clone the project**
   ```bash
   git clone https://github.com/yourusername/teraplayer.git
   cd teraplayer
   
   npm install
   
   # Production mode
npm start

# Development mode (requires nodemon)
npm run dev