document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const urlInput = document.getElementById('urlInput');
    const pasteBtn = document.getElementById('pasteBtn');
    const convertBtn = document.getElementById('convertBtn');
    const errorBox = document.getElementById('errorBox');
    const errorText = document.getElementById('errorText');
    const loader = document.getElementById('loader');
    const resultArea = document.getElementById('resultArea');
    const vidTitle = document.getElementById('vidTitle');
    const vidSize = document.getElementById('vidSize');
    const dlBtn = document.getElementById('dlBtn');

    let playerInstance = null;

    // --- UTILITIES ---
    const formatBytes = (bytes, decimals = 2) => {
        if (!+bytes) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
    };

    const showError = (msg) => {
        errorText.textContent = msg;
        errorBox.classList.remove('hidden');
        setTimeout(() => errorBox.classList.add('hidden'), 5000);
    };

    const initPlayer = (source) => {
        if (playerInstance) playerInstance.destroy();
        
        const videoEl = document.getElementById('player');
        videoEl.src = source;

        playerInstance = new Plyr(videoEl, {
            controls: [
                'play-large', 'play', 'progress', 'current-time', 
                'mute', 'volume', 'captions', 'settings', 'pip', 'airplay', 'fullscreen'
            ],
            autoplay: false
        });
    };

    // --- EVENT LISTENERS ---

    // Paste from Clipboard
    pasteBtn.addEventListener('click', async () => {
        try {
            const text = await navigator.clipboard.readText();
            urlInput.value = text;
            urlInput.focus();
        } catch (err) {
            showError('Clipboard permission denied. Please press Ctrl+V manually.');
        }
    });

    // Enter Key Support
    urlInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') processUrl();
    });

    // Convert Button
    convertBtn.addEventListener('click', processUrl);

    // --- MAIN LOGIC ---

    async function processUrl() {
        const url = urlInput.value.trim();

        // 1. Validation
        if (!url) return showError('Please paste a URL first.');
        if (!url.includes('terabox')) return showError('Invalid TeraBox link detected.');

        // 2. UI Reset
        errorBox.classList.add('hidden');
        resultArea.classList.add('hidden');
        loader.classList.remove('hidden');
        convertBtn.disabled = true;
        convertBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Processing...';

        try {
            // 3. API Call
            const response = await fetch('/api/convert', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url })
            });

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || 'Unknown error occurred');
            }

            // 4. Update Result UI
            const data = result.data;
            vidTitle.textContent = data.filename || 'TeraBox Video';
            vidSize.textContent = formatBytes(data.size);
            
            // Set Download Link
            dlBtn.href = data.download_url;

            // Initialize Player
            initPlayer(data.stream_url);

            // Show Result
            loader.classList.add('hidden');
            resultArea.classList.remove('hidden');
            resultArea.scrollIntoView({ behavior: 'smooth', block: 'center' });

        } catch (error) {
            loader.classList.add('hidden');
            showError(error.message);
        } finally {
            convertBtn.disabled = false;
            convertBtn.innerHTML = '<span>Play Video</span> <i class="fa-solid fa-arrow-right"></i>';
        }
    }
});